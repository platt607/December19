# Write any code you like in here
# Run your code from the 'Run current' menu item above
# Open the README.md file for more instructions




# Import the modules
import sys
import random

import sys
'''
Section 1: Collect customer input
'''

##Collect Customer Data - Part 1

##1)	Request Rental code:
#Prompt --> "(B)udget, (D)aily, or (W)eekly rental?"
#rentalCode = ?
rentalCode = input("(B)udget, (D)aily, or (W)eekly rental?\n")

#2)	Request time period the car was rented.

#Prompt --> "Number of Days Rented:"
#rentalPeriod = ?
#	OR
#Prompt --> "Number of Weeks Rented:"
#rentalPeriod = ?
if rentalCode=="D":
  rentalPeriod = input("Number of Days Rented?\n")
elif rentalCode=="W":
  rentalPeriod = input("Number of Weeks Rented?\n")
#CUSTOMER DATA CHECK 1
#ADD CODE HERE TO PRINT:
#rentalCode
#rentalPeriod
nthNumbers = []
if stop < N:
  print(numbers)
elif N > 0:
  nthNumbers = numbers
  nthNumbers = [M * i for i in nthNumbers[N::N]]
  for j in range (len(numbers)):
        if numbers[j]==N:
          numbers.insert(j, j)
  
print(nthNumbers)
print(numbers) 

#Calculation Part 1

##Set the base charge for the rental type as the variable baseCharge. 
#The base charge is the rental period * the appropriate rate:
#break
else:
  for j in range (len(numbers)):
        if numbers[j]==N:
          for k in numbers:
            k = M * numbers[j]
            
        
        elif numbers[j]==N*2:
          for l in numbers:
            l = M * numbers[j]
            
            
numbers[(N)] = k
numbers[(N)+N] =l
print(numbers)